# WA Folders agent bridge 1.3.1

Lets your AI agent (Claude Desktop, Cursor, Codex, any MCP app) use the WhatsApp folders you allow in WA Folders. Local only: no server, no network, never sends WhatsApp messages.

1. Install Node.js 18+.
2. Run `install-windows.ps1` (Windows, PowerShell) or `bash install-mac-linux.sh` (Mac/Linux).
3. In WA Folders Settings > AI agent access: turn it on and tick the folders the agent may read. Optional: allow adding chats to folders and setting reminders.
4. Add the MCP server the installer printed to your agent. Example (Claude Desktop config):
   `{"mcpServers":{"wa-folders":{"command":"node","args":["<path>/wa-folders-agent.js"]}}}`

Tools: list_folders, list_chats, search, get_chat_notes, summarize_chat, add_to_folder, set_reminder.

What leaves your computer: WA Folders itself sends nothing to any WA Folders server. Your agent app may send what it reads to its own AI service. summarize_chat sends the chat's name, note and last 8 messages to YOUR AI provider (the key in Private AI) and only works if you turn on the separate "send chat summaries to my AI provider" toggle.

add_to_folder can only move a chat that is already in a ticked folder into another ticked folder; it can never pull in a chat from an unticked folder.
Resources: one `wafolders://folder/<id>` digest per allowed folder (names, notes, reminders, last 8 snippets per chat; 16,000 characters max: about 4k tokens in English, more in languages such as Chinese or Japanese).
Revoke any time: Settings > Revoke all agent access (also removes Chrome's native-messaging permission).

Security notes:
- Mac/Linux: the local socket is ~/.wa-folders/agent.sock, in a folder only you can open (0700), created owner-only (umask 077).
- Chrome only launches the bridge for the WA Folders extension id (allowed_origins in the native-host manifest); the bridge also checks that exact origin.
- Any program running as you can talk to the socket while Chrome is open, the same as it could read your Chrome profile.
- Windows limitation: the pipe name is per user, but Windows does not let the bridge lock the pipe to your account. Another account signed in to the same PC at the same time could connect while Chrome is open. Use it on a PC where you are the only user, or turn AI agent access off when others use it.
- If the agent says WA Folders "is not reachable", Chrome is closed or asleep: open Chrome and wait about 30 seconds. If it says access is "turned off", turn it on in Settings.
