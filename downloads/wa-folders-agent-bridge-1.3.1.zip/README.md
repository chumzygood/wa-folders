# WA Folders agent bridge 1.3.1

Lets your AI agent (Claude Desktop, Cursor, Codex, any MCP app) use the WhatsApp folders you allow in WA Folders. Local only: no server, no network, never sends WhatsApp messages.

1. Install Node.js 18+.
2. Run `install-windows.ps1` (Windows, PowerShell) or `bash install-mac-linux.sh` (Mac/Linux).
3. In WA Folders Settings > AI agent access: turn it on and tick the folders the agent may read. Optional: allow adding chats to folders and setting reminders.
4. Add the MCP server the installer printed to your agent. Example (Claude Desktop config):
   `{"mcpServers":{"wa-folders":{"command":"node","args":["<path>/wa-folders-agent.js"]}}}`

Tools: list_folders, list_chats, search, get_chat_notes, summarize_chat (your own AI key), add_to_folder, set_reminder.
Resources: one `wafolders://folder/<id>` digest per allowed folder (names, notes, reminders, last 8 snippets per chat; about 4k tokens max).
Revoke any time: Settings > Revoke all agent access (also removes Chrome's native-messaging permission).
