#!/usr/bin/env bash
# Installs the WA Folders agent bridge for Chrome (macOS / Linux). Needs Node 18+. No network.
set -euo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
NODE="$(command -v node || true)"; [ -n "$NODE" ] || { echo "Install Node.js 18+ first (https://nodejs.org)"; exit 1; }
umask 077
DEST="$HOME/.wa-folders-agent"; mkdir -p "$DEST"; chmod 700 "$DEST"; cp "$DIR/wa-folders-agent.js" "$DEST/"; chmod 600 "$DEST/wa-folders-agent.js"
# Private socket directory (the bridge also enforces 0700 and ownership at start).
mkdir -p "$HOME/.wa-folders"; chmod 700 "$HOME/.wa-folders"
printf '#!/bin/sh\nexec "%s" "%s/wa-folders-agent.js" "$@"\n' "$NODE" "$DEST" > "$DEST/host.sh"; chmod 700 "$DEST/host.sh"
if [ "$(uname)" = "Darwin" ]; then T="$HOME/Library/Application Support/Google/Chrome/NativeMessagingHosts"; else T="$HOME/.config/google-chrome/NativeMessagingHosts"; fi
mkdir -p "$T"
cat > "$T/com.wafolders.agent.json" <<J
{ "name": "com.wafolders.agent", "description": "WA Folders agent bridge", "path": "$DEST/host.sh", "type": "stdio",
  "allowed_origins": ["chrome-extension://hahfpdlfieloofgjhanljbbnakinfhil/"] }
J
chmod 644 "$T/com.wafolders.agent.json"
echo "Installed. Add this MCP server to your AI agent:"
echo "  command: $NODE   args: [\"$DEST/wa-folders-agent.js\"]"
echo "Uninstall: rm -rf \"$DEST\" \"$HOME/.wa-folders\" \"$T/com.wafolders.agent.json\""
