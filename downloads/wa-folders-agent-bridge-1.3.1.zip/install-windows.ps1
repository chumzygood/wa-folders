# Installs the WA Folders agent bridge for Chrome on Windows (current user, no admin). Needs Node 18+. No network.
$ErrorActionPreference = "Stop"
$node = (Get-Command node -ErrorAction SilentlyContinue).Source
if (-not $node) { Write-Host "Install Node.js 18+ first (https://nodejs.org)"; exit 1 }
$dest = Join-Path $env:LOCALAPPDATA "WA-Folders-Agent"
New-Item -ItemType Directory -Force -Path $dest | Out-Null
Copy-Item (Join-Path $PSScriptRoot "wa-folders-agent.js") $dest -Force
Set-Content -Path (Join-Path $dest "host.bat") -Value "@echo off`r`n`"$node`" `"$dest\wa-folders-agent.js`" %*" -Encoding ASCII
$manifest = @{ name = "com.wafolders.agent"; description = "WA Folders agent bridge"; path = (Join-Path $dest "host.bat"); type = "stdio"; allowed_origins = @("chrome-extension://hahfpdlfieloofgjhanljbbnakinfhil/") } | ConvertTo-Json
$mpath = Join-Path $dest "com.wafolders.agent.json"
[IO.File]::WriteAllText($mpath, $manifest)
New-Item -Path "HKCU:\Software\Google\Chrome\NativeMessagingHosts\com.wafolders.agent" -Force | Out-Null
Set-ItemProperty -Path "HKCU:\Software\Google\Chrome\NativeMessagingHosts\com.wafolders.agent" -Name "(default)" -Value $mpath
Write-Host "Installed. Add this MCP server to your AI agent:"
Write-Host "  command: $node   args: [`"$dest\wa-folders-agent.js`"]"
Write-Host "Uninstall: Remove-Item -Recurse `"$dest`"; Remove-Item `"HKCU:\Software\Google\Chrome\NativeMessagingHosts\com.wafolders.agent`""
