# Installs the WA Folders agent bridge for Chrome on Windows (current user, no admin). Needs Node 18+. No network.
$ErrorActionPreference = "Stop"
$node = (Get-Command node -ErrorAction SilentlyContinue).Source
if (-not $node) { Write-Host "Install Node.js 18+ first (https://nodejs.org)"; exit 1 }
$dest = Join-Path $env:LOCALAPPDATA "WA-Folders-Agent"
New-Item -ItemType Directory -Force -Path $dest | Out-Null
# Only this user (and SYSTEM) may change the bridge files Chrome launches.
$icaclsOut = & icacls $dest /inheritance:r /grant:r "$($env:USERNAME):(OI)(CI)F" "*S-1-5-18:(OI)(CI)F" 2>&1
if ($LASTEXITCODE -ne 0) {
  Write-Host "ERROR: could not lock down permissions on $dest (icacls exit code $LASTEXITCODE). Nothing was registered with Chrome." -ForegroundColor Red
  Write-Host ($icaclsOut | Out-String)
  exit 2
}
# Verify: inheritance must be off and only this user and SYSTEM may be listed.
$acl = Get-Acl $dest
$allowed = @([Security.Principal.NTAccount]"$env:USERDOMAIN\$env:USERNAME", [Security.Principal.SecurityIdentifier]"S-1-5-18") | ForEach-Object { try { $_.Translate([Security.Principal.SecurityIdentifier]).Value } catch { $null } }
$extra = @($acl.Access | Where-Object { $allowed -notcontains $_.IdentityReference.Translate([Security.Principal.SecurityIdentifier]).Value })
if (-not $acl.AreAccessRulesProtected -or $extra.Count -gt 0) {
  Write-Host "ERROR: permissions on $dest are not locked to this user and SYSTEM. Nothing was registered with Chrome." -ForegroundColor Red
  exit 2
}
Copy-Item (Join-Path $PSScriptRoot "wa-folders-agent.js") $dest -Force
Set-Content -Path (Join-Path $dest "host.bat") -Value "@echo off`r`n`"$node`" `"$dest\wa-folders-agent.js`" %*" -Encoding ASCII
$manifest = @{ name = "com.wafolders.agent"; description = "WA Folders agent bridge"; path = (Join-Path $dest "host.bat"); type = "stdio"; allowed_origins = @("chrome-extension://hahfpdlfieloofgjhanljbbnakinfhil/") } | ConvertTo-Json
$mpath = Join-Path $dest "com.wafolders.agent.json"
[IO.File]::WriteAllText($mpath, $manifest)
New-Item -Path "HKCU:\Software\Google\Chrome\NativeMessagingHosts\com.wafolders.agent" -Force | Out-Null
Set-ItemProperty -Path "HKCU:\Software\Google\Chrome\NativeMessagingHosts\com.wafolders.agent" -Name "(default)" -Value $mpath
Write-Host "Note: on Windows, another account signed in to this same PC could connect to the local pipe while Chrome is open. Use this only on a PC where you are the only user, or turn AI agent access off when others use it."
Write-Host "Installed. Add this MCP server to your AI agent:"
Write-Host "  command: $node   args: [`"$dest\wa-folders-agent.js`"]"
Write-Host "Uninstall: Remove-Item -Recurse `"$dest`"; Remove-Item `"HKCU:\Software\Google\Chrome\NativeMessagingHosts\com.wafolders.agent`""
