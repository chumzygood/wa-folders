#!/usr/bin/env node
/* WA Folders agent bridge 1.3.1. No network: local pipe/socket only.
 *   node wa-folders-agent.js            -> MCP server on stdio (point your AI agent here)
 *   (launched by Chrome with chrome-extension://... arg) -> native messaging host
 * The native host relays MCP-server requests to the WA Folders extension. */
"use strict";
const net = require("net"), os = require("os"), path = require("path"), fs = require("fs");
const VERSION = "1.3.1";
const EXT_ORIGIN = "chrome-extension://hahfpdlfieloofgjhanljbbnakinfhil/";
/* F-3b: POSIX socket lives in a private ~/.wa-folders/ directory (0700), not world-writable tmp.
 * Windows: the pipe name is per-user, but Node cannot set a pipe DACL; see README "Windows limitation". */
const SOCK_DIR = process.env.WA_FOLDERS_AGENT_DIR || path.join(os.homedir(), ".wa-folders");
const SOCK = process.env.WA_FOLDERS_AGENT_SOCK || (process.platform === "win32"
  ? "\\\\.\\pipe\\wa-folders-agent-" + os.userInfo().username
  : path.join(SOCK_DIR, "agent.sock"));
const ERR_ASLEEP = "WA Folders is not reachable: Chrome is closed or its WA Folders link is asleep. Open Chrome (WA Folders reconnects within about 30 seconds) and try again.";
const ERR_DISABLED = "AI agent access is turned off in WA Folders. Turn it on in WA Folders Settings > AI agent access.";
function privateDir(dir) {
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
  const st = fs.lstatSync(dir);
  if (!st.isDirectory() || st.isSymbolicLink()) throw new Error("socket directory is not a real directory: " + dir);
  if (typeof process.getuid === "function" && st.uid !== process.getuid()) throw new Error("socket directory not owned by this user: " + dir);
  fs.chmodSync(dir, 0o700);
}

/* ---- Chrome native messaging framing (4-byte LE length + JSON) ---- */
function nmEncode(obj) { const b = Buffer.from(JSON.stringify(obj)); const h = Buffer.alloc(4); h.writeUInt32LE(b.length); return Buffer.concat([h, b]); }
function nmDecoder(onMsg) {
  let buf = Buffer.alloc(0);
  return (chunk) => {
    buf = Buffer.concat([buf, chunk]);
    while (buf.length >= 4) { const n = buf.readUInt32LE(0); if (buf.length < 4 + n) break; const s = buf.slice(4, 4 + n).toString(); buf = buf.slice(4 + n); try { onMsg(JSON.parse(s)); } catch (e) {} }
  };
}
function lineDecoder(onMsg) {
  let s = "";
  return (chunk) => { s += chunk.toString(); let i; while ((i = s.indexOf("\n")) >= 0) { const l = s.slice(0, i).trim(); s = s.slice(i + 1); if (l) { try { onMsg(JSON.parse(l)); } catch (e) {} } } };
}

/* ---- Native host: Chrome <-> local socket ---- */
function runHost(input = process.stdin, output = process.stdout) {
  const pending = new Map(); let seq = 0;
  input.on("data", nmDecoder((m) => { const p = pending.get(m.id); if (p) { pending.delete(m.id); p.write(JSON.stringify({ id: p._rid, result: m.result, error: m.error }) + "\n"); } }));
  input.on("end", () => process.exit(0));
  if (process.platform !== "win32") {
    privateDir(path.dirname(SOCK));
    try { fs.unlinkSync(SOCK); } catch (e) {}
    process.umask(0o077); /* F-3a: socket is created owner-only atomically, no chmod race */
  }
  const srv = net.createServer((c) => {
    c.on("data", lineDecoder((r) => { const id = ++seq; c._rid = r.id; const w = { write: (s) => c.write(s), _rid: r.id }; pending.set(id, w); output.write(nmEncode({ id, method: r.method, params: r.params || {} })); }));
  });
  srv.listen(SOCK);
  return srv;
}

/* ---- MCP server (stdio JSON-RPC) -> local socket ---- */
const TOOLS = [
  ["list_folders", "List the WA Folders folders the user allowed for AI agents.", {}],
  ["list_chats", "List chats (title, note, reminder) in an allowed folder.", { folder: "Folder id or name" }],
  ["search", "Search chat titles, notes and indexed text inside allowed folders.", { query: "Text to find" }],
  ["get_chat_notes", "Get a chat's note, reminder and recent snippets (allowed folders only).", { chat: "Chat id from list_chats" }],
  ["summarize_chat", "Summarize a chat by sending its name, note and last messages to the user's own AI provider (needs the user's separate AI-summaries toggle).", { chat: "Chat id" }],
  ["add_to_folder", "Add a chat that is already in an allowed folder to another allowed folder (needs the user's write toggle). Never sends WhatsApp messages.", { chat: "Chat id", folder: "Folder id or name" }],
  ["set_reminder", "Set a WA Folders reminder on a chat (needs the write toggle). Never sends WhatsApp messages.", { chat: "Chat id", at: "ISO 8601 time" }]
].map(([name, description, props]) => ({ name, description, inputSchema: { type: "object", properties: Object.fromEntries(Object.entries(props).map(([k, v]) => [k, { type: "string", description: v }])), required: Object.keys(props) } }));

function askExt(method, params, sock = SOCK, timeout = 30000) {
  return new Promise((resolve) => {
    const c = net.connect(sock); const t = setTimeout(() => { c.destroy(); resolve({ error: "timeout" }); }, timeout);
    c.on("error", () => { clearTimeout(t); resolve({ error: ERR_ASLEEP }); });
    c.on("connect", () => c.write(JSON.stringify({ id: 1, method, params }) + "\n"));
    c.on("data", lineDecoder((m) => { clearTimeout(t); c.end(); resolve(m); }));
  });
}

async function mcpHandle(req, ask = askExt) {
  const ok = (result) => ({ jsonrpc: "2.0", id: req.id, result });
  const errText = (e) => (e === "disabled" ? ERR_DISABLED : e);
  const text = (r) => ok({ content: [{ type: "text", text: r.error ? "Error: " + errText(r.error) : (typeof r.result === "string" ? r.result : JSON.stringify(r.result, null, 2)) }], isError: !!r.error });
  switch (req.method) {
    case "initialize": return ok({ protocolVersion: (req.params && req.params.protocolVersion) || "2025-06-18", capabilities: { tools: {}, resources: {} }, serverInfo: { name: "wa-folders", version: VERSION } });
    case "tools/list": return ok({ tools: TOOLS });
    case "tools/call": { const p = req.params || {}; if (!TOOLS.some((t) => t.name === p.name)) return { jsonrpc: "2.0", id: req.id, error: { code: -32602, message: "unknown tool" } }; return text(await ask(p.name, p.arguments || {})); }
    case "resources/list": { const r = await ask("list_resources", {}); if (r.error) return { jsonrpc: "2.0", id: req.id, error: { code: -32002, message: errText(r.error) } }; return ok({ resources: r.result || [] }); } /* Claude 1.3.1 recheck note 1: never an empty list on error */
    case "resources/read": { const r = await ask("read_resource", { uri: req.params && req.params.uri }); if (r.error) return { jsonrpc: "2.0", id: req.id, error: { code: -32002, message: errText(r.error) } }; return ok({ contents: [{ uri: req.params.uri, mimeType: "text/markdown", text: r.result }] }); }
    case "ping": return ok({});
    default: return req.id === undefined ? null : { jsonrpc: "2.0", id: req.id, error: { code: -32601, message: "method not found" } };
  }
}

function runMcp() {
  process.stdin.on("data", lineDecoder(async (req) => { const r = await mcpHandle(req); if (r) process.stdout.write(JSON.stringify(r) + "\n"); }));
}

function isChromeLaunch(argv) { return argv.includes(EXT_ORIGIN); } /* F-3e: exact origin, not a prefix */
module.exports = { nmEncode, nmDecoder, mcpHandle, askExt, runHost, TOOLS, EXT_ORIGIN, ERR_ASLEEP, ERR_DISABLED, isChromeLaunch, privateDir };
if (require.main === module) {
  if (isChromeLaunch(process.argv)) runHost(); else runMcp();
}
